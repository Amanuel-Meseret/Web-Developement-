<?php
$con=mysqli_connect("www.ijopost.com","ijopostcom_jewa","Am@python36","ijopostcom_blog");
// Check connection
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }
 ?>