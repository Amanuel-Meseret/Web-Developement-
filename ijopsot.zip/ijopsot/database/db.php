<?php
	$database_username = 'ijopostcom_jewa';//user name
	$database_password = 'Am@python36';//password
	$pdo_conn = new PDO( 'mysql:host=www.ijopost.com;dbname=ijopostcom_blog', $database_username, $database_password );
?>
