<?php
//database connection
($GLOBALS["___mysqli_ston"] = mysqli_connect("www.ijopost.com","ijopostcom_jewa","Am@python36","ijopostcom_blog"));  //host,user,password,database
?>
