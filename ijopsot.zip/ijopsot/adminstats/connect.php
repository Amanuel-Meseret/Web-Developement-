<?php
$dsn='mysql:host=www.ijopost.com;dbname=ijopostcom_blog';//dbname and host
$username='ijopostcom_jewa';//username
$password='Am@python36';//password
?>