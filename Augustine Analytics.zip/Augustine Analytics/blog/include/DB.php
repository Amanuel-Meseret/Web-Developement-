<?php


$Connection=mysqli_connect('localhost','root','','phpcms');


?>